﻿using ComboBoxMVVMExample.ViewModel; // ViewModelBase.cs
using System;

using System.Collections.Generic; // List<Country>
using System.IO;
//using System.ComponentModel; // [Description("")]

namespace ComboBoxMVVMExample.Model
{
    public class ExampleModel
    {
    }
    /// <summary>
    /// Country object
    /// </summary>
    public class Country
    {
        public string CountryName { get; set; }
        public string CountryTwoLetterCode { get; set; }

        public List<Country> getCountries()
        {
            List<Country> returnCountries = new List<Country>();
            returnCountries.Add(new Country() { CountryName = "Almaty", CountryTwoLetterCode = "AL" });
            returnCountries.Add(new Country() { CountryName = "Astana", CountryTwoLetterCode = "AS" });
            returnCountries.Add(new Country() { CountryName = "Aktau", CountryTwoLetterCode = "AK" });
            return returnCountries;
        }
    }

    /// <summary>
    /// State object
    /// </summary>
    public class State
    {
        public string CountryTwoLetterCode { get; set; }
        public string StateName { get; set; }

        public List<State> getStatesCollection()
        {
            List<State> returnStates = new List<State>();
            returnStates.Add(new State() { CountryTwoLetterCode = "AL", StateName = "Almaty_1" });
            returnStates.Add(new State() { CountryTwoLetterCode = "AL", StateName = "Almaty_2" });
            returnStates.Add(new State() { CountryTwoLetterCode = "AL", StateName = "Almaty_3" });
            returnStates.Add(new State() { CountryTwoLetterCode = "AS", StateName = "Astana_1" });
            returnStates.Add(new State() { CountryTwoLetterCode = "AS", StateName = "Astana_2" });
            returnStates.Add(new State() { CountryTwoLetterCode = "AS", StateName = "Astana_3" });
            returnStates.Add(new State() { CountryTwoLetterCode = "AK", StateName = "Aktau_1" });
            returnStates.Add(new State() { CountryTwoLetterCode = "AK", StateName = "Aktau_2" });
            returnStates.Add(new State() { CountryTwoLetterCode = "AK", StateName = "Aktau_3" });
            return returnStates;
        }

        /// <summary>
        /// Employee object
        /// </summary>
        

        public List<State> getStateByCountryCode(string countryCode)
        {
            List<State> stateList = new List<State>();
            foreach (State currentState in getStatesCollection())
            {
                if (currentState.CountryTwoLetterCode == countryCode)
                {
                    stateList.Add(new State() { CountryTwoLetterCode = currentState.CountryTwoLetterCode, StateName = currentState.StateName });
                }
            }
            return stateList;
        }   
    }

    public class Employee
    {
        public string StateName { get; set; }
        public string EmployeeCode { get; set; }

        public List<Employee> getEmployeesCollection()
        {
            List<Employee> returnEmployees = new List<Employee>();
            returnEmployees.Add(new Employee() { StateName = "Almaty_1", EmployeeCode = "Иванов" });
            returnEmployees.Add(new Employee() { StateName = "Almaty_1", EmployeeCode = "Искендиров" });
            returnEmployees.Add(new Employee() { StateName = "Almaty_2", EmployeeCode = "Синицын" });
            returnEmployees.Add(new Employee() { StateName = "Almaty_2", EmployeeCode = "Кузнецов" });
            returnEmployees.Add(new Employee() { StateName = "Almaty_3", EmployeeCode = "Попов" });
            returnEmployees.Add(new Employee() { StateName = "Almaty_3", EmployeeCode = "Васильев" });
            returnEmployees.Add(new Employee() { StateName = "Astana_1", EmployeeCode = "Соколов" });
            returnEmployees.Add(new Employee() { StateName = "Astana_1", EmployeeCode = "Николаев" });
            returnEmployees.Add(new Employee() { StateName = "Astana_2", EmployeeCode = "Сидоров" });
            returnEmployees.Add(new Employee() { StateName = "Astana_2", EmployeeCode = "Лазарев" });
            returnEmployees.Add(new Employee() { StateName = "Astana_3", EmployeeCode = "Карпов" });
            returnEmployees.Add(new Employee() { StateName = "Astana_3", EmployeeCode = "Сафонов" });
            returnEmployees.Add(new Employee() { StateName = "Aktau_1", EmployeeCode = "Зыков" });
            returnEmployees.Add(new Employee() { StateName = "Aktau_1", EmployeeCode = "Щукин" });
            returnEmployees.Add(new Employee() { StateName = "Aktau_2", EmployeeCode = "Бирюков" });
            returnEmployees.Add(new Employee() { StateName = "Aktau_2", EmployeeCode = "Маслов" });
            returnEmployees.Add(new Employee() { StateName = "Aktau_3", EmployeeCode = "Жуков" });
            returnEmployees.Add(new Employee() { StateName = "Aktau_3", EmployeeCode = "Вишняков" });
            return returnEmployees;
        }

        public List<Employee> getEmployeeByStateName(string _stateName)
        {
            List<Employee> EmployeeList = new List<Employee>();
            foreach (Employee currentName in getEmployeesCollection())
            {
                if (currentName.StateName == _stateName)
                {
                    EmployeeList.Add(new Employee() { StateName = currentName.StateName, EmployeeCode = currentName.EmployeeCode });
                }
            }
            return EmployeeList;
        }
    }
}
